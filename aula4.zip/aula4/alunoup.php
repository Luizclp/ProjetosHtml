<html>
<head>
<title>Alteração de Alunos</title>
<?php include ('config.php'); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="alunoup.php?botao=gravar" method="post" name="form1">
<table width="95%" border="1" align="center">
  <tr>
    <td colspan="5" align="center">Alteração de Alunos</td>
  </tr>
  <tr>
    <td width="18%" align="right">Matricula:</td>
    <td width="26%"><input type="number" name="matricula" /></td>
    <td width="18%" align="right">Nome:</td>
    <td width="26%"><input type="text" name="nome" /></td>
    <td width="18%" align="right">CPF:</td>
    <td width="26%"><input type="text" name="cpf" /></td>
    <td width="18%" align="right">Data de Nascimento:</td>
    <td width="26%"><input type="date" name="data_nscto" /></td>
    <td width="21%"><input type="submit" name="botao" value="Alterar" /></td>
  </tr>
</table>
</form>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['botao']) && $_POST['botao'] == "Alterar") {
    $id = intval($_POST['matricula']);
    $idade = intval($_POST['data_nscto']);
    $nome = mysqli_real_escape_string($mysqli, $_POST['nome']);


    if ($matricula > 0) {

        if ($matricula > 0) {
            mysqli_query($mysqli, "UPDATE cliente SET data_nascimento='$data_nscto' WHERE matricula='$matricula'");
        }

        if (!empty($nome)) {
            mysqli_query($mysqli, "UPDATE cliente SET nome='$data_nscto' WHERE matricula='$matricula'");
        }

        mysqli_close($mysqli);
    } else {
        echo "Matricula inválido.";
    }
}
?>

<a href="index.html">Home</a>
</body>
</html>