<html>

<head>
<title>Cadastro de Alunos</title>

<?php include ('config.php');  ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="aluno.php" method="post" name="aluno">
<table width="200" border="1">
  <tr>
    <td colspan="2">Cadastro de Alunos</td>
  </tr>
  <tr>
    <td width="53">Cod.</td>
    <td width="131">&nbsp;
  </tr>
  <tr>
    <td>Nome:</td>
    <td><input type="text" name="nome" ></td>
  </tr>
  <tr>
    <td>Matricula:</td>
    <td><input type="text" name="matricula" ></td>
  </tr>
    <tr>
    <td>Data de Nascimento:</td>
    <td><input type="text" name="data_nscto" ></td>
  </tr>
  <tr>
    <td>CPF:</td>
    <td><input type="text" name="cpf" ></td>
  </tr>
  <tr>
    <td colspan="2" align="right"><input type="submit" value="Gravar" name="botao"></td>
    </tr>	
</table>
</form>

<?php
if (@$_POST['botao'] == "Gravar") 
	{
		
		$nome = $_POST['nome'];
		$matricula = $_POST['matricula'];
		$cpf = $_POST['cpf'];
		$data_nscto = $_POST['data_nscto'];
		
		$insere = "INSERT into aluno (nome, matricula, cpf, data_nscto) 
    VALUES ('$nome', '$matricula', '$cpf', '$data_nscto')";
		mysqli_query($mysqli, $insere) or die ("Não foi possivel inserir os dados");
	}

?>

<a href="index.html" >Home </a>
</body>
</html>